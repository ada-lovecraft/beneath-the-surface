'use strict';


var GameManager  = (function() {
  var _cache = {};
  return {
    get: function(id) {
      return _cache[id];
    },
    add: function(id, obj) {
      if(!_cache.hasOwnProperty(id)) {
        _cache[id] = obj;
      } else {
        throw 'GameManager already contains: ' + id;
      }
    }
  };
})();

module.exports = GameManager;