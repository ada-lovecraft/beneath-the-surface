'use strict';

var CommonCold = require('../prefabs/commonCold');

var LevelManager  = function() {
  this.levels = [
    {
      score: 0,
      respawnRate: 500,
      maxEnemies: 5,
      enemyTypes: [
        {
          enemyClass: CommonCold,
          id: 'commonCold'
        }
      ],
    },
    {
      score: 10,
      respawnRate: 1000,
      maxEnemies: 10,
      enemyTypes: [
        {
          enemyClass: CommonCold,
          id: 'commonCold'
        }
      ],
    }
  ];

};

LevelManager.prototype.get = function(score) {
  var possible = _.filter(this.levels, function(level) {
    return level.score <= score;
  });
  return _.last(possible);
};

module.exports = LevelManager;