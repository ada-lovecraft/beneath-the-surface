'use strict';

var CommonCold = require('../prefabs/common-cold');
var Player = require('../prefabs/player');
var Oxygen = require('../prefabs/oxygen');

exports.whiteBloodCell = {
  id: 'whiteBloodCell',
  name: 'The White Blood Cell',
  description: 'The hero of our story',
  mechanics: 'Fast, agile, and loaded with antivirals. Kill the bad guys, protect the innocents, and be awesome.\n\nClick to shoot. WASD to move',
  color: 'white',
  spriteClass: Player
};

exports.commonCold = {
  id: 'commonCold',
  name: 'The Common Cold',
  description: 'The most annoying virus in the world',
  mechanics: 'Slow, dumb, and weak, the common cold will wander around and just generally make you annoyed.\n\nOne Shot. One Kill.',
  color: '#33d743',
  spriteClass: CommonCold
};

exports.oxygen = {
  id: 'oxygen',
  name: 'Oxygen',
  description: 'Your life\'s blood\'s life\'s blood',
  mechanics: 'Randomly floats by in the blood stream and is also released when a blood cell dies.\n\nReplenishes a damaged red blood cell\'s health',
  color: '#4e8cff',
  spriteClass: Oxygen
};
